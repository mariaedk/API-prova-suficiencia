package br.com.api.prova;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiRestProvaApplicationTests {

	@Test
	void contextLoads() {
	}

}
